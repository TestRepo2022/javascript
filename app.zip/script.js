var Books = [];

var BookObj = function (title, price, author) {
  this.title = title;
  this.price = price;
  this.author = author;
};

function AddBook() {
  var title = _("title").value;
  var price = _("price").value;
  var author = _("author").value;
  var index = _("index").value;
  var book = new BookObj(title, price, author);

  if (index == "") {
    Books.push(book);
  } else {
    Books.splice(index, 1, book);
    _("btn").innerText = "Add Book";
  }
  BindBook(Books);
  resetForm();
}

function BindBook(books) {
  var rows = `<tr><th>SNo.</th><th>Title</th><th>Price</th><th>Author</th><th>Action</th></tr>`;
  books.forEach(function (book, index) {
    rows += `<tr><td>${index + 1}</td><td>${book.title}</td><td>${
      book.price
    }</td><td>${
      book.author
    }</td><td><a href='#' onclick='editrecord(${index})'>Edit</a>||<a href='#' onclick='deleterecord(${index})'>delete</a></td></tr>`;
    _("tbl_data").innerHTML = rows;
  });
}

function deleterecord(index) {
  Books.splice(index, 1);
  BindBook(Books);
}

function editrecord(index) {
  var book = Books[index];
  _("title").value = book.title;
  _("price").value = book.price;
  _("author").value = book.author;
  _("index").value = index;
  _("btn").innerText = "Update Book";
}
function _(id) {
  return document.getElementById(id);
}

_("btn").addEventListener("click", AddBook);

function resetForm() {
  document.forms[0].reset();
}
